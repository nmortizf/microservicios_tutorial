package dao;

import java.util.List;
import model.Hotel;

public interface HotelesDao {
	
	public List<Hotel> devolverHoteles();

}


