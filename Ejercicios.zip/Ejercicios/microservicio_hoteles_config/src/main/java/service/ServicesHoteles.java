package service;

import java.util.List;
import model.Hotel;

public interface ServicesHoteles {
	
	public List<Hotel> devolverHotelesDisponibles();

}


